import { createBrowserRouter } from "react-router"

import { MainLayout } from "@/layouts/MainLayout"
import { HomePage } from "@/routes/HomePage"
import { NotFoundPage } from "@/routes/NotFoundPage"

export const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
])
