# Essentials Mart

Production-grade supermarket platform — repository bootstrap.

This repository contains the foundational setup only: tooling, folder
structure, routing, layout shell, and provider configuration. Authentication,
product catalog, and business logic are intentionally not implemented yet.

## Tech Stack

- [React 19](https://react.dev)
- [TypeScript](https://www.typescriptlang.org)
- [Vite](https://vite.dev)
- [React Router](https://reactrouter.com) (v8, data mode)
- [Tailwind CSS](https://tailwindcss.com) (v4)
- [shadcn/ui](https://ui.shadcn.com)
- [TanStack Query](https://tanstack.com/query)
- [Zustand](https://zustand.docs.pmnd.rs)
- [React Hook Form](https://react-hook-form.com)
- [Zod](https://zod.dev)

## Requirements

- Node.js 22+
- npm 10+

## Installation

Clone the repository and install dependencies:

```bash
git clone <repository-url>
cd essentials-mart
npm install
```

## Development

Start the local development server with hot module replacement:

```bash
npm run dev
```

The app runs at `http://localhost:5173` by default.

Other useful commands during development:

```bash
npm run lint          # Lint the codebase with ESLint
npm run lint:fix       # Lint and auto-fix issues
npm run format          # Format the codebase with Prettier
npm run format:check    # Check formatting without writing changes
npm run type-check      # Type-check the app without emitting output
```

## Build

Create a production build:

```bash
npm run build
```

This type-checks the project and outputs static assets to `dist/`.

Preview the production build locally:

```bash
npm run preview
```

## Adding shadcn/ui Components

shadcn/ui is configured (`components.json`). Add new components with the CLI:

```bash
npx shadcn@latest add <component-name>
```

Generated components are placed in `src/components/ui`.

## Project Structure

```
essentials-mart/
├── public/                  # Static assets served as-is
│   └── favicon.svg
├── src/
│   ├── app/                 # Root application component (providers + router)
│   │   └── App.tsx
│   ├── assets/               # Images, fonts, and other bundled static assets
│   ├── components/           # Shared, reusable UI components
│   │   └── ui/                # shadcn/ui components
│   │       └── button.tsx
│   ├── features/             # Feature-specific modules (domain logic, colocated by feature)
│   ├── hooks/                 # Shared custom React hooks
│   ├── layouts/               # Page layout shells
│   │   ├── Header.tsx
│   │   ├── Footer.tsx
│   │   └── MainLayout.tsx
│   ├── lib/                    # Framework-agnostic helpers and client instances
│   │   ├── query-client.ts       # TanStack Query client configuration
│   │   └── utils.ts               # Shared utilities (e.g. cn class merger)
│   ├── providers/               # App-wide context/provider wrappers
│   │   └── QueryProvider.tsx
│   ├── routes/                    # Route definitions and page components
│   │   ├── router.tsx               # Router configuration
│   │   ├── HomePage.tsx
│   │   └── NotFoundPage.tsx
│   ├── services/                  # API/service layer (external data access)
│   ├── store/                       # Zustand global state store
│   │   └── index.ts
│   ├── styles/                       # Global styles and Tailwind theme
│   │   └── globals.css
│   ├── types/                         # Shared TypeScript types
│   ├── utils/                          # Generic utility functions
│   ├── main.tsx                          # Application entry point
│   └── vite-env.d.ts
├── components.json                        # shadcn/ui configuration
├── eslint.config.js                        # ESLint flat configuration
├── index.html                               # HTML entry point
├── package.json
├── tsconfig.json                             # TypeScript project references
├── tsconfig.app.json                          # App TypeScript configuration
├── tsconfig.node.json                          # Node/tooling TypeScript configuration
├── vite.config.ts                               # Vite configuration
└── README.md
```

## Routing

Routing is configured with React Router's data mode (`createBrowserRouter`).
Current routes:

| Path | Component      | Description              |
| ---- | -------------- | ------------------------ |
| `/`  | `HomePage`     | Placeholder landing page |
| `*`  | `NotFoundPage` | Catch-all 404 page       |

All routes render inside `MainLayout`, which provides the shared
`Header`, `main` content area, and `Footer`.

## State & Data

- **TanStack Query** is configured via `QueryProvider` and a shared
  `queryClient` (`src/lib/query-client.ts`) for future server-state needs.
- **Zustand** is configured with an empty global store (`src/store/index.ts`)
  ready to be extended as client-state needs arise.

## Path Aliases

The `@/*` alias resolves to `src/*` and is configured consistently across
`tsconfig.json`, `tsconfig.app.json`, `vite.config.ts`, and `components.json`.

```ts
import { cn } from "@/lib/utils"
```
