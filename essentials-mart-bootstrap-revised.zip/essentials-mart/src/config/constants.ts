/**
 * Application-wide constants.
 */

export const APP_NAME = "Essentials Mart"
