/**
 * Route path constants.
 */

export const ROUTES = {
  home: "/",
} as const
