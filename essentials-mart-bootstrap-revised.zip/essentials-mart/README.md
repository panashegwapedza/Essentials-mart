# Essentials Mart

Production-grade supermarket platform — repository bootstrap.

This repository contains the foundational setup only: tooling, folder
structure, routing, layout shell, and provider configuration. Authentication,
product catalog, and business logic are intentionally not implemented yet.

## Tech Stack

- [React 19](https://react.dev)
- [TypeScript](https://www.typescriptlang.org)
- [Vite](https://vite.dev)
- [React Router](https://reactrouter.com) (v8, data mode)
- [Tailwind CSS](https://tailwindcss.com) (v4)
- [shadcn/ui](https://ui.shadcn.com)
- [TanStack Query](https://tanstack.com/query)
- [Zustand](https://zustand.docs.pmnd.rs)
- [React Hook Form](https://react-hook-form.com)
- [Zod](https://zod.dev)

## Requirements

- Node.js 20+
- npm 10+

## Installation

Clone the repository and install dependencies:

```bash
git clone <repository-url>
cd essentials-mart
npm install
```

## Development

Start the local development server with hot module replacement:

```bash
npm run dev
```

The app runs at `http://localhost:5173` by default.

Other useful commands during development:

```bash
npm run lint          # Lint the codebase with ESLint
npm run lint:fix       # Lint and auto-fix issues
npm run format          # Format the codebase with Prettier
npm run format:check    # Check formatting without writing changes
npm run type-check      # Type-check the app without emitting output
```

## Build

Create a production build:

```bash
npm run build
```

This type-checks the project and outputs static assets to `dist/`.

Preview the production build locally:

```bash
npm run preview
```

## Adding shadcn/ui Components

shadcn/ui is configured (`components.json`). Add new components with the CLI:

```bash
npx shadcn@latest add <component-name>
```

Generated components are placed in `src/components/ui`.

## Project Structure

```
essentials-mart/
├── public/                  # Static assets served as-is
│   └── favicon.svg
├── src/
│   ├── app/                 # Root application component (providers + router)
│   │   └── App.tsx
│   ├── assets/               # Images, fonts, and other bundled static assets
│   ├── components/           # Shared, reusable UI components
│   │   └── ui/                # shadcn/ui components
│   │       └── button.tsx
│   ├── config/                # App configuration (API, constants, env, routes, theme)
│   │   ├── api.ts
│   │   ├── constants.ts
│   │   ├── env.ts
│   │   ├── routes.ts
│   │   └── theme.ts
│   ├── features/             # Feature-specific modules (domain logic, colocated by feature)
│   │   ├── home/
│   │   │   └── HomePage.tsx
│   │   └── system/
│   │       └── NotFoundPage.tsx
│   ├── hooks/                 # Shared custom React hooks
│   ├── layouts/               # Page layout shells
│   │   ├── Header.tsx
│   │   ├── Footer.tsx
│   │   └── MainLayout.tsx
│   ├── lib/                    # Framework-agnostic helpers and client instances
│   │   ├── query-client.ts       # TanStack Query client configuration
│   │   └── utils.ts               # Shared utilities (e.g. cn class merger)
│   ├── providers/               # App-wide context/provider wrappers
│   │   └── QueryProvider.tsx
│   ├── routes/                    # Router configuration only
│   │   └── router.tsx
│   ├── services/                  # API/service layer (external data access)
│   ├── store/                       # Zustand global state store
│   │   └── app-store.ts
│   ├── styles/                       # Global styles and Tailwind theme
│   │   └── globals.css
│   ├── types/                         # Shared TypeScript types
│   ├── utils/                          # Generic utility functions
│   ├── main.tsx                          # Application entry point
│   └── vite-env.d.ts
├── components.json                        # shadcn/ui configuration
├── eslint.config.js                        # ESLint flat configuration
├── index.html                               # HTML entry point
├── package.json
├── tsconfig.json                             # TypeScript project references
├── tsconfig.app.json                          # App TypeScript configuration
├── tsconfig.node.json                          # Node/tooling TypeScript configuration
├── vite.config.ts                               # Vite configuration
└── README.md
```

## Routing

Routing is configured with React Router's data mode (`createBrowserRouter`).
The `src/routes/` folder holds only router configuration; page components
live in their respective feature folders. Current routes:

| Path | Component      | Component Location              | Description              |
| ---- | -------------- | -------------------------------- | ------------------------ |
| `/`  | `HomePage`     | `src/features/home/HomePage.tsx` | Placeholder landing page |
| `*`  | `NotFoundPage` | `src/features/system/NotFoundPage.tsx` | Catch-all 404 page |

All routes render inside `MainLayout`, which provides the shared
`Header`, `main` content area, and `Footer`.

## State & Data

- **TanStack Query** is configured via `QueryProvider` and a shared
  `queryClient` (`src/lib/query-client.ts`) for future server-state needs.
- **Zustand** is configured with an empty global store
  (`src/store/app-store.ts`) ready to be extended as client-state needs arise.

## Project Architecture

- **Feature-first architecture** — page components and feature-specific
  logic live under `src/features/<feature-name>/`. The `src/routes/` folder
  is limited to router configuration (`router.tsx`) and simply wires paths
  to the components exported by each feature.
- **Shared UI components** — reusable, non-feature-specific components
  (including shadcn/ui components) live in `src/components/`, e.g.
  `src/components/ui/button.tsx`.
- **Providers** — app-wide context/provider wrappers (e.g. `QueryProvider`)
  live in `src/providers/` and are composed together in `src/app/App.tsx`.
- **Configuration folder** — `src/config/` centralizes starter constants
  and helpers such as the API base URL (`api.ts`), shared constants
  (`constants.ts`), environment helpers (`env.ts`), route path constants
  (`routes.ts`), and the default theme (`theme.ts`).
- **Zustand store** — global client state is managed via a single store at
  `src/store/app-store.ts`, currently empty and ready to be extended.
- **TanStack Query** — server-state management is configured via
  `QueryProvider` and a shared `queryClient` in `src/lib/query-client.ts`.

## Path Aliases

The `@/*` alias resolves to `src/*` and is configured consistently across
`tsconfig.json`, `tsconfig.app.json`, `vite.config.ts`, and `components.json`.

```ts
import { cn } from "@/lib/utils"
```
