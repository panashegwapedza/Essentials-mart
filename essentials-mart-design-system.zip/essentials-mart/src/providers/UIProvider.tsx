import type { ReactNode } from "react"

import { Toaster } from "@/components/ui/toaster"
import { TooltipProvider } from "@/components/ui/tooltip"

interface UIProviderProps {
  children: ReactNode
}

/**
 * Wires up shared design-system UI infrastructure — the Radix Tooltip
 * context and the toast renderer — once at the root of the app.
 */
export function UIProvider({ children }: UIProviderProps) {
  return (
    <TooltipProvider>
      {children}
      <Toaster />
    </TooltipProvider>
  )
}
