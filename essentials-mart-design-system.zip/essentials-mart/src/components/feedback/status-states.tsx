import * as React from "react"

import { AlertCircle, AlertTriangle, CheckCircle2, Inbox, Info, WifiOff } from "@/components/icons"
import { EmptyState } from "@/components/ui/empty-state"
import { Spinner } from "@/components/ui/spinner"
import { cn } from "@/lib/utils"

type StateProps = Omit<React.ComponentProps<typeof EmptyState>, "icon">

/** A resolved, positive outcome — e.g. an action completed successfully. */
function SuccessState(props: StateProps) {
  return <EmptyState icon={CheckCircle2} {...props} />
}

/** Something failed and the user needs to know. */
function ErrorState(props: StateProps) {
  return <EmptyState icon={AlertCircle} {...props} />
}

/** A caution the user should be aware of before continuing. */
function WarningState(props: StateProps) {
  return <EmptyState icon={AlertTriangle} {...props} />
}

/** Neutral, informational messaging. */
function InfoState(props: StateProps) {
  return <EmptyState icon={Info} {...props} />
}

/** There is simply nothing to show yet. */
function NoDataState(props: StateProps) {
  return <EmptyState icon={Inbox} {...props} />
}

/** The client has lost network connectivity. */
function OfflineState(props: StateProps) {
  return <EmptyState icon={WifiOff} {...props} />
}

interface LoadingStateProps extends React.ComponentProps<"div"> {
  label?: string
}

/** A blocking, in-progress state for a section of UI. */
function LoadingState({ className, label = "Loading", ...props }: LoadingStateProps) {
  return (
    <div
      className={cn(
        "flex flex-col items-center justify-center gap-3 rounded-lg border border-dashed border-border px-6 py-12 text-center",
        className
      )}
      {...props}
    >
      <Spinner label={label} className="size-5" />
      <p className="text-small text-muted-foreground">{label}</p>
    </div>
  )
}

export {
  SuccessState,
  ErrorState,
  WarningState,
  InfoState,
  NoDataState,
  OfflineState,
  LoadingState,
}
