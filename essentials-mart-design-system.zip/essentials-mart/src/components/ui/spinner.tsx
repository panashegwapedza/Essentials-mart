import { Loader2 } from "@/components/icons"
import { cn } from "@/lib/utils"

interface SpinnerProps extends React.ComponentProps<typeof Loader2> {
  label?: string
}

function Spinner({ className, label = "Loading", ...props }: SpinnerProps) {
  return (
    <span role="status" className="inline-flex items-center gap-2">
      <Loader2
        data-slot="spinner"
        className={cn("size-4 animate-spin text-muted-foreground", className)}
        aria-hidden="true"
        {...props}
      />
      <span className="sr-only">{label}</span>
    </span>
  )
}

export { Spinner }
