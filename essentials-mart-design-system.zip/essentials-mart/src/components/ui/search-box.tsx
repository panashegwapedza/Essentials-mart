import * as React from "react"

import { Search, X } from "@/components/icons"
import { Input } from "@/components/ui/input"
import { cn } from "@/lib/utils"

interface SearchBoxProps extends Omit<React.ComponentProps<typeof Input>, "type" | "onChange"> {
  onValueChange?: (value: string) => void
  onClear?: () => void
}

function SearchBox({ className, onValueChange, onClear, value, ...props }: SearchBoxProps) {
  return (
    <div className={cn("relative", className)}>
      <Search
        className="pointer-events-none absolute top-1/2 left-3 size-4 -translate-y-1/2 text-muted-foreground"
        aria-hidden="true"
      />
      <Input
        type="search"
        value={value}
        onChange={(event) => onValueChange?.(event.target.value)}
        className="pr-8 pl-9"
        {...props}
      />
      {value ? (
        <button
          type="button"
          onClick={onClear}
          aria-label="Clear search"
          className="absolute top-1/2 right-2 -translate-y-1/2 text-muted-foreground transition-colors hover:text-foreground focus-visible:outline-none"
        >
          <X className="size-3.5" aria-hidden="true" />
        </button>
      ) : null}
    </div>
  )
}

export { SearchBox }
