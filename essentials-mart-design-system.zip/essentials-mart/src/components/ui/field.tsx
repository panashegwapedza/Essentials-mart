import * as React from "react"

import { Label } from "@/components/ui/label"
import { cn } from "@/lib/utils"

function Field({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="field" className={cn("group flex flex-col gap-1.5", className)} {...props} />
  )
}

function FieldLabel({ className, ...props }: React.ComponentProps<typeof Label>) {
  return <Label data-slot="field-label" className={className} {...props} />
}

function RequiredIndicator({ className, ...props }: React.ComponentProps<"span">) {
  return (
    <span
      data-slot="required-indicator"
      aria-hidden="true"
      className={cn("text-danger", className)}
      {...props}
    >
      *
    </span>
  )
}

function FieldHint({ className, ...props }: React.ComponentProps<"p">) {
  return (
    <p
      data-slot="field-hint"
      className={cn("text-caption text-muted-foreground", className)}
      {...props}
    />
  )
}

function FieldError({ className, children, ...props }: React.ComponentProps<"p">) {
  if (!children) return null

  return (
    <p
      data-slot="field-error"
      role="alert"
      className={cn("text-caption font-medium text-danger", className)}
      {...props}
    >
      {children}
    </p>
  )
}

export { Field, FieldLabel, RequiredIndicator, FieldHint, FieldError }
