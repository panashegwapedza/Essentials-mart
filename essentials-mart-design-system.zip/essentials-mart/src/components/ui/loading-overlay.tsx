import * as React from "react"

import { Spinner } from "@/components/ui/spinner"
import { cn } from "@/lib/utils"

interface LoadingOverlayProps extends React.ComponentProps<"div"> {
  label?: string
  /** Set false to render inline instead of covering the nearest positioned ancestor. */
  cover?: boolean
}

function LoadingOverlay({
  className,
  label = "Loading",
  cover = true,
  ...props
}: LoadingOverlayProps) {
  return (
    <div
      data-slot="loading-overlay"
      className={cn(
        "flex items-center justify-center gap-2 bg-background/70 backdrop-blur-sm",
        cover && "absolute inset-0 z-(--z-overlay)",
        className
      )}
      {...props}
    >
      <Spinner label={label} className="size-5" />
    </div>
  )
}

export { LoadingOverlay }
