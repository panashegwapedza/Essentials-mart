import * as React from "react"

import { X } from "@/components/icons"
import { cn } from "@/lib/utils"

interface ChipProps extends React.ComponentProps<"span"> {
  onRemove?: () => void
  removeLabel?: string
}

function Chip({ className, children, onRemove, removeLabel = "Remove", ...props }: ChipProps) {
  return (
    <span
      data-slot="chip"
      className={cn(
        "inline-flex items-center gap-1.5 rounded-full border border-border bg-secondary px-3 py-1 text-small font-medium text-secondary-foreground",
        className
      )}
      {...props}
    >
      {children}
      {onRemove ? (
        <button
          type="button"
          onClick={onRemove}
          aria-label={removeLabel}
          className="-mr-1 rounded-full p-0.5 text-muted-foreground transition-colors hover:bg-foreground/10 hover:text-foreground focus-visible:outline-none"
        >
          <X className="size-3" aria-hidden="true" />
        </button>
      ) : null}
    </span>
  )
}

export { Chip }
