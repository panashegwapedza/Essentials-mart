import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const textVariants = cva("text-foreground", {
  variants: {
    variant: {
      display: "text-display font-semibold tracking-tight",
      h1: "text-h1 font-semibold tracking-tight",
      h2: "text-h2 font-semibold tracking-tight",
      h3: "text-h3 font-semibold tracking-tight",
      h4: "text-h4 font-semibold tracking-tight",
      "body-lg": "text-body-lg font-normal",
      body: "text-body font-normal",
      small: "text-small font-normal text-muted-foreground",
      caption: "text-caption font-normal text-muted-foreground",
      label: "text-label font-medium",
      mono: "text-small font-mono",
    },
  },
  defaultVariants: {
    variant: "body",
  },
})

type TextElement = "h1" | "h2" | "h3" | "h4" | "p" | "span" | "code" | "label"

interface TextProps extends React.HTMLAttributes<HTMLElement>, VariantProps<typeof textVariants> {
  as?: TextElement
}

/** Base typography primitive. Prefer the named exports below in most cases. */
function Text({ className, variant, as, ...props }: TextProps) {
  const Comp = (as ?? "p") as React.ElementType
  return <Comp data-slot="text" className={cn(textVariants({ variant, className }))} {...props} />
}

const Display = (props: Omit<TextProps, "variant" | "as">) => (
  <Text as="h1" variant="display" {...props} />
)
const H1 = (props: Omit<TextProps, "variant" | "as">) => <Text as="h1" variant="h1" {...props} />
const H2 = (props: Omit<TextProps, "variant" | "as">) => <Text as="h2" variant="h2" {...props} />
const H3 = (props: Omit<TextProps, "variant" | "as">) => <Text as="h3" variant="h3" {...props} />
const H4 = (props: Omit<TextProps, "variant" | "as">) => <Text as="h4" variant="h4" {...props} />
const BodyLarge = (props: Omit<TextProps, "variant" | "as">) => (
  <Text as="p" variant="body-lg" {...props} />
)
const Body = (props: Omit<TextProps, "variant" | "as">) => <Text as="p" variant="body" {...props} />
const Small = (props: Omit<TextProps, "variant" | "as">) => (
  <Text as="span" variant="small" {...props} />
)
const Caption = (props: Omit<TextProps, "variant" | "as">) => (
  <Text as="span" variant="caption" {...props} />
)
const TextLabel = (props: Omit<TextProps, "variant" | "as">) => (
  <Text as="span" variant="label" {...props} />
)
const Mono = (props: Omit<TextProps, "variant" | "as">) => (
  <Text as="code" variant="mono" {...props} />
)

export {
  Text,
  textVariants,
  Display,
  H1,
  H2,
  H3,
  H4,
  BodyLarge,
  Body,
  Small,
  Caption,
  TextLabel,
  Mono,
}
