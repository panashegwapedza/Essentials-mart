/**
 * Central icon export.
 *
 * Components must not import from "lucide-react" directly — import from
 * "@/components/icons" instead. This keeps the icon set swappable in one
 * place and gives every consumer a single, typed import source.
 */
export {
  AlertCircle,
  AlertTriangle,
  Check,
  CheckCircle2,
  ChevronDown,
  ChevronLeft,
  ChevronRight,
  ChevronsLeft,
  ChevronsRight,
  ChevronsUpDown,
  ChevronUp,
  Circle,
  Eye,
  EyeOff,
  Inbox,
  Info,
  Loader2,
  Minus,
  MoreHorizontal,
  Search,
  User,
  WifiOff,
  X,
  XCircle,
  type LucideIcon,
  type LucideProps,
} from "lucide-react"
