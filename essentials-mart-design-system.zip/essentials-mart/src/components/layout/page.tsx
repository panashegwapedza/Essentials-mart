import * as React from "react"

import { cn } from "@/lib/utils"

function Page({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="page"
      className={cn("flex min-h-svh w-full flex-col bg-background text-foreground", className)}
      {...props}
    />
  )
}

export { Page }
