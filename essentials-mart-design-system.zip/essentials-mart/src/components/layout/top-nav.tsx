import * as React from "react"

import { cn } from "@/lib/utils"

function TopNav({ className, ...props }: React.ComponentProps<"header">) {
  return (
    <header
      data-slot="top-nav"
      className={cn(
        "sticky top-0 z-(--z-sticky) flex h-14 w-full shrink-0 items-center gap-4 border-b border-border bg-surface px-4 text-surface-foreground",
        className
      )}
      {...props}
    />
  )
}

function TopNavStart({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="top-nav-start"
      className={cn("flex flex-1 items-center gap-3", className)}
      {...props}
    />
  )
}

function TopNavEnd({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div data-slot="top-nav-end" className={cn("flex items-center gap-2", className)} {...props} />
  )
}

export { TopNav, TopNavStart, TopNavEnd }
