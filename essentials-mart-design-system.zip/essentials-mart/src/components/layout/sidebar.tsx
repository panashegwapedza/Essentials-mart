import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const sidebarVariants = cva(
  "flex h-full shrink-0 flex-col border-r border-border bg-surface text-surface-foreground",
  {
    variants: {
      width: {
        sm: "w-56",
        default: "w-64",
        lg: "w-72",
      },
    },
    defaultVariants: {
      width: "default",
    },
  }
)

function Sidebar({
  className,
  width,
  ...props
}: React.ComponentProps<"aside"> & VariantProps<typeof sidebarVariants>) {
  return (
    <aside data-slot="sidebar" className={cn(sidebarVariants({ width, className }))} {...props} />
  )
}

function SidebarHeader({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-header"
      className={cn("flex h-14 shrink-0 items-center border-b border-border px-4", className)}
      {...props}
    />
  )
}

function SidebarContent({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-content"
      className={cn("flex-1 overflow-y-auto p-2", className)}
      {...props}
    />
  )
}

function SidebarFooter({ className, ...props }: React.ComponentProps<"div">) {
  return (
    <div
      data-slot="sidebar-footer"
      className={cn("shrink-0 border-t border-border p-2", className)}
      {...props}
    />
  )
}

export { Sidebar, SidebarHeader, SidebarContent, SidebarFooter, sidebarVariants }
