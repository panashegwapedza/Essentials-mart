import * as React from "react"

import { cn } from "@/lib/utils"

function Content({ className, ...props }: React.ComponentProps<"main">) {
  return <main data-slot="content" className={cn("flex-1 overflow-y-auto", className)} {...props} />
}

export { Content }
