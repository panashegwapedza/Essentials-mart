import * as React from "react"
import { cva, type VariantProps } from "class-variance-authority"

import { cn } from "@/lib/utils"

const containerVariants = cva("mx-auto w-full px-6", {
  variants: {
    size: {
      narrow: "max-w-(--container-narrow)",
      content: "max-w-(--container-content)",
      wide: "max-w-(--container-wide)",
      full: "max-w-none",
    },
  },
  defaultVariants: {
    size: "content",
  },
})

function Container({
  className,
  size,
  ...props
}: React.ComponentProps<"div"> & VariantProps<typeof containerVariants>) {
  return (
    <div data-slot="container" className={cn(containerVariants({ size, className }))} {...props} />
  )
}

export { Container, containerVariants }
