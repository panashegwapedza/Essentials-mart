import { RouterProvider } from "react-router/dom"

import { QueryProvider } from "@/providers/QueryProvider"
import { UIProvider } from "@/providers/UIProvider"
import { router } from "@/routes/router"

export function App() {
  return (
    <QueryProvider>
      <UIProvider>
        <RouterProvider router={router} />
      </UIProvider>
    </QueryProvider>
  )
}
