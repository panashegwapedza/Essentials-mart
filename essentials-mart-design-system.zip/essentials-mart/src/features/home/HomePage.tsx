export function HomePage() {
  return (
    <section className="mx-auto flex min-h-[calc(100svh-8rem)] w-full max-w-6xl flex-col items-center justify-center px-6 py-24 text-center">
      <span className="mb-6 inline-flex items-center rounded-full border border-border px-3 py-1 text-xs font-medium uppercase tracking-widest text-muted-foreground">
        Platform Foundation
      </span>
      <h1 className="text-balance text-5xl font-semibold tracking-tight sm:text-6xl">
        Essentials Mart
      </h1>
      <p className="mt-4 max-w-xl text-balance text-lg text-muted-foreground">
        Next Generation Supermarket Platform
      </p>
    </section>
  )
}
