import { Link } from "react-router"

export function NotFoundPage() {
  return (
    <section className="mx-auto flex min-h-[calc(100svh-8rem)] w-full max-w-6xl flex-col items-center justify-center px-6 py-24 text-center">
      <span className="text-sm font-medium uppercase tracking-widest text-muted-foreground">
        404
      </span>
      <h1 className="mt-4 text-4xl font-semibold tracking-tight">Page not found</h1>
      <p className="mt-4 max-w-md text-balance text-muted-foreground">
        The page you are looking for doesn&apos;t exist or has been moved.
      </p>
      <Link
        to="/"
        className="mt-8 text-sm font-medium text-primary underline-offset-4 hover:underline"
      >
        Return home
      </Link>
    </section>
  )
}
