import { createBrowserRouter } from "react-router"

import { HomePage } from "@/features/home/HomePage"
import { NotFoundPage } from "@/features/system/NotFoundPage"
import { MainLayout } from "@/layouts/MainLayout"

export const router = createBrowserRouter([
  {
    path: "/",
    element: <MainLayout />,
    children: [
      { index: true, element: <HomePage /> },
      { path: "*", element: <NotFoundPage /> },
    ],
  },
])
