import * as React from "react"

import { Content } from "@/components/layout/content"
import { Page } from "@/components/layout/page"
import { Sidebar } from "@/components/layout/sidebar"
import { TopNav } from "@/components/layout/top-nav"

interface DashboardLayoutProps {
  /** Sidebar navigation content — composed by the consuming feature. */
  sidebar: React.ReactNode
  /** Top bar content — composed by the consuming feature. */
  topNav?: React.ReactNode
  children: React.ReactNode
}

/**
 * Generic dashboard shell: fixed sidebar, optional top bar, scrollable
 * content area. Carries no navigation items or business logic of its own —
 * those are supplied by whatever feature renders this layout.
 */
export function DashboardLayout({ sidebar, topNav, children }: DashboardLayoutProps) {
  return (
    <Page className="flex-row">
      <Sidebar>{sidebar}</Sidebar>
      <div className="flex min-w-0 flex-1 flex-col">
        {topNav ? <TopNav>{topNav}</TopNav> : null}
        <Content className="p-6">{children}</Content>
      </div>
    </Page>
  )
}
