import { Outlet } from "react-router"

import { Footer } from "@/layouts/Footer"
import { Header } from "@/layouts/Header"

export function MainLayout() {
  return (
    <div className="flex min-h-svh flex-col bg-background text-foreground">
      <Header />
      <main className="flex-1">
        <Outlet />
      </main>
      <Footer />
    </div>
  )
}
