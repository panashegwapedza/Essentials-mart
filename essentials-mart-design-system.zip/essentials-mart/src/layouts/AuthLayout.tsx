import * as React from "react"

import { Container } from "@/components/layout/container"
import { Page } from "@/components/layout/page"

interface AuthLayoutProps {
  /** Optional logo/branding slot rendered above the card. */
  header?: React.ReactNode
  children: React.ReactNode
}

/**
 * Centered, single-column shell for authentication-style screens.
 * Renders no form or auth logic of its own.
 */
export function AuthLayout({ header, children }: AuthLayoutProps) {
  return (
    <Page className="items-center justify-center py-12">
      <Container size="narrow" className="flex flex-col items-center gap-8">
        {header}
        <div className="w-full rounded-lg border border-border bg-surface p-8 text-surface-foreground shadow-elevation-2">
          {children}
        </div>
      </Container>
    </Page>
  )
}
