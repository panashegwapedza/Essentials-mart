export function Footer() {
  return (
    <footer className="border-t border-border">
      <div className="mx-auto flex w-full max-w-6xl flex-col items-center justify-between gap-2 px-6 py-6 text-sm text-muted-foreground sm:flex-row">
        <span>© {new Date().getFullYear()} Essentials Mart</span>
        <span>Next Generation Supermarket Platform</span>
      </div>
    </footer>
  )
}
