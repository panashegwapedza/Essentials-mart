export function Header() {
  return (
    <header className="border-b border-border">
      <div className="mx-auto flex h-16 w-full max-w-6xl items-center px-6">
        <span className="text-lg font-semibold tracking-tight">Essentials Mart</span>
      </div>
    </header>
  )
}
