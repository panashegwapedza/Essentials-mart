import * as React from "react"

import type { ToastVariant } from "@/components/ui/toast"

const TOAST_LIMIT = 3
const TOAST_REMOVE_DELAY = 5000

interface ToastRecord {
  id: string
  title?: React.ReactNode
  description?: React.ReactNode
  action?: React.ReactNode
  variant?: ToastVariant
  open: boolean
}

type ToastInput = Omit<ToastRecord, "id" | "open">

type Action =
  | { type: "ADD_TOAST"; toast: ToastRecord }
  | { type: "DISMISS_TOAST"; toastId?: string }
  | { type: "REMOVE_TOAST"; toastId?: string }

let count = 0
function genId() {
  count = (count + 1) % Number.MAX_SAFE_INTEGER
  return count.toString()
}

const listeners: Array<(state: { toasts: ToastRecord[] }) => void> = []
let memoryState: { toasts: ToastRecord[] } = { toasts: [] }

function dispatch(action: Action) {
  memoryState = reducer(memoryState, action)
  listeners.forEach((listener) => listener(memoryState))
}

function reducer(state: { toasts: ToastRecord[] }, action: Action): { toasts: ToastRecord[] } {
  switch (action.type) {
    case "ADD_TOAST":
      return { toasts: [action.toast, ...state.toasts].slice(0, TOAST_LIMIT) }
    case "DISMISS_TOAST":
      return {
        toasts: state.toasts.map((t) =>
          t.id === action.toastId || action.toastId === undefined ? { ...t, open: false } : t
        ),
      }
    case "REMOVE_TOAST":
      if (action.toastId === undefined) return { toasts: [] }
      return { toasts: state.toasts.filter((t) => t.id !== action.toastId) }
    default:
      return state
  }
}

function toast(input: ToastInput) {
  const id = genId()

  const update = (next: ToastInput) =>
    dispatch({ type: "ADD_TOAST", toast: { ...next, id, open: true } })
  const dismiss = () => dispatch({ type: "DISMISS_TOAST", toastId: id })

  dispatch({ type: "ADD_TOAST", toast: { ...input, id, open: true } })

  setTimeout(() => {
    dismiss()
    setTimeout(() => dispatch({ type: "REMOVE_TOAST", toastId: id }), 300)
  }, TOAST_REMOVE_DELAY)

  return { id, update, dismiss }
}

function useToast() {
  const [state, setState] = React.useState(memoryState)

  React.useEffect(() => {
    listeners.push(setState)
    return () => {
      const index = listeners.indexOf(setState)
      if (index > -1) listeners.splice(index, 1)
    }
  }, [])

  return {
    ...state,
    toast,
    dismiss: (toastId?: string) => dispatch({ type: "DISMISS_TOAST", toastId }),
  }
}

export { useToast, toast }
