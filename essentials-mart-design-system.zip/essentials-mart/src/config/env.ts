/**
 * Centralized access to environment-derived values.
 * Extend as new import.meta.env variables are introduced.
 */

export const isDev = import.meta.env.DEV
export const isProd = import.meta.env.PROD
export const mode = import.meta.env.MODE
