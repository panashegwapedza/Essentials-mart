/**
 * API configuration.
 * No requests are made from this file — it only defines shared constants
 * for future service modules under src/services.
 */

export const API_BASE_URL = import.meta.env.VITE_API_BASE_URL ?? ""

export const API_TIMEOUT_MS = 15_000
