/**
 * Route path constants.
 * Keep in sync with the route definitions in src/routes/router.tsx.
 */

export const ROUTES = {
  home: "/",
} as const
