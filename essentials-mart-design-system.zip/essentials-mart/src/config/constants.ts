/**
 * Application-wide constants that don't belong to a single feature.
 */

export const APP_NAME = "Essentials Mart"

export const APP_DESCRIPTION = "Next Generation Supermarket Platform"
