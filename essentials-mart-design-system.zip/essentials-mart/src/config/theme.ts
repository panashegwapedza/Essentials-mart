/**
 * Theme configuration.
 * Color tokens themselves live in src/styles/globals.css; this file
 * only exposes theme identifiers for use in JS/TS logic.
 */

export const DEFAULT_THEME = "light"

export const THEMES = ["light", "dark"] as const

export type Theme = (typeof THEMES)[number]
