/**
 * Reusable formatting helpers used across the design system and app.
 * Kept generic and side-effect free — no business rules baked in.
 */

interface FormatCurrencyOptions {
  currency?: string
  locale?: string
}

export function formatCurrency(
  value: number,
  { currency = "USD", locale = "en-US" }: FormatCurrencyOptions = {}
): string {
  return new Intl.NumberFormat(locale, {
    style: "currency",
    currency,
  }).format(value)
}

interface FormatDateOptions {
  locale?: string
  dateStyle?: Intl.DateTimeFormatOptions["dateStyle"]
}

export function formatDate(
  date: Date | string | number,
  { locale = "en-US", dateStyle = "medium" }: FormatDateOptions = {}
): string {
  const parsed = date instanceof Date ? date : new Date(date)
  return new Intl.DateTimeFormat(locale, { dateStyle }).format(parsed)
}

interface FormatNumberOptions {
  locale?: string
  maximumFractionDigits?: number
}

export function formatNumber(
  value: number,
  { locale = "en-US", maximumFractionDigits = 0 }: FormatNumberOptions = {}
): string {
  return new Intl.NumberFormat(locale, { maximumFractionDigits }).format(value)
}

export function truncate(value: string, maxLength: number): string {
  if (value.length <= maxLength) return value
  return `${value.slice(0, Math.max(0, maxLength - 1)).trimEnd()}…`
}
