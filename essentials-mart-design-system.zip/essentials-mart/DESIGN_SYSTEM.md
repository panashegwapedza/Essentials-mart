# Essentials Mart — Design System

A single, consistent component foundation for every future screen in the
project — storefront, admin dashboard, inventory, checkout, authentication,
analytics, and beyond.

## Design Philosophy

Modern, minimal, premium, fast, accessible. Think Linear, Stripe Dashboard,
Vercel, Shopify — restrained geometry, purposeful motion, high-contrast
text, no cartoon-like or overly rounded styling. Every visual decision is
expressed as a token, never hardcoded in a component.

## Getting Started

```tsx
import { Button, Card, CardContent } from "@/components/ui"
import { Container, Stack } from "@/components/layout"
```

Each category has a single barrel import:

| Import from             | Contains                                               |
| ----------------------- | ------------------------------------------------------ |
| `@/components/ui`       | All primitives — buttons, inputs, dialogs, etc.        |
| `@/components/layout`   | Layout primitives — Container, Stack, Grid, Page, etc. |
| `@/components/feedback` | Status states — Success/Error/Warning/... State        |
| `@/components/icons`    | The only place icons are imported from                 |
| `@/utils/format`        | formatCurrency, formatDate, formatNumber, truncate     |

## Design Tokens

All tokens live in `src/styles/globals.css` as CSS variables, mapped into
Tailwind's `@theme` so they're consumable as ordinary utility classes
(`bg-primary`, `text-h2`, `shadow-elevation-2`, `rounded-lg`, …).

### Color

Semantic tokens only — never hardcode a hex/oklch value in a component.

| Token                       | Utility example                      | Purpose                           |
| --------------------------- | ------------------------------------ | --------------------------------- |
| `primary` / `-foreground`   | `bg-primary text-primary-foreground` | Primary actions                   |
| `secondary` / `-foreground` | `bg-secondary`                       | Secondary actions                 |
| `success` / `-foreground`   | `bg-success`                         | Positive status                   |
| `warning` / `-foreground`   | `bg-warning`                         | Caution status                    |
| `danger` / `-foreground`    | `bg-danger` (alias of destructive)   | Destructive / error status        |
| `info` / `-foreground`      | `bg-info`                            | Neutral, informational status     |
| `muted` / `-foreground`     | `bg-muted text-muted-foreground`     | De-emphasized content             |
| `background` / `foreground` | `bg-background text-foreground`      | Page canvas                       |
| `surface` / `-foreground`   | `bg-surface` (alias of card)         | Elevated panels — cards, popovers |
| `border` / `input` / `ring` | `border-border`                      | Borders and focus rings           |

Light and dark themes are defined in `:root` and `.dark` respectively;
toggle dark mode by adding the `dark` class to a parent element (e.g.
`<html>`). No component needs to change — every color is theme-aware by
construction.

### Typography

| Token      | Utility class       | Use                    |
| ---------- | ------------------- | ---------------------- |
| Display    | `text-display`      | Hero headlines         |
| H1–H4      | `text-h1`…`text-h4` | Section headings       |
| Body Large | `text-body-lg`      | Lead paragraphs        |
| Body       | `text-body`         | Default copy           |
| Small      | `text-small`        | Secondary copy         |
| Caption    | `text-caption`      | Timestamps, meta text  |
| Label      | `text-label`        | Form labels, UI chrome |
| Mono       | `font-mono`         | Code, IDs, SKUs        |

Prefer the components in `@/components/ui` (`Display`, `H1`…`H4`,
`BodyLarge`, `Body`, `Small`, `Caption`, `TextLabel`, `Mono`) over applying
the classes by hand — they also set sensible default HTML elements and
weights.

### Spacing

Uses Tailwind's default 4px-based spacing scale (`p-1`…`p-96`, `gap-*`,
etc.) throughout — no separate spacing scale was introduced, so every
existing Tailwind spacing utility applies consistently.

### Elevation

| Token                 | Utility              |
| --------------------- | -------------------- |
| Elevation 1 (subtle)  | `shadow-elevation-1` |
| Elevation 2 (raised)  | `shadow-elevation-2` |
| Elevation 3 (overlay) | `shadow-elevation-3` |
| Elevation 4 (modal)   | `shadow-elevation-4` |

### Motion

| Token               | Value                          |
| ------------------- | ------------------------------ |
| `--duration-fast`   | 120ms                          |
| `--duration-base`   | 200ms                          |
| `--duration-slow`   | 350ms                          |
| `--ease-standard`   | `cubic-bezier(0.4, 0, 0.2, 1)` |
| `--ease-emphasized` | `cubic-bezier(0.2, 0, 0, 1)`   |

Enter/exit animations for overlays (Dialog, Drawer, Popover, Tooltip,
Select, Toast) use the `tw-animate-css` utility classes (`animate-in`,
`fade-in-0`, `zoom-in-95`, `slide-in-from-*`), driven by Radix's
`data-state` attributes.

### Container Widths

`narrow` (40rem), `content` (65rem), `wide` (80rem), `full` — set via the
`<Container size="...">` prop.

### Breakpoints

Tailwind's defaults are used unmodified: `sm` 40rem, `md` 48rem, `lg` 64rem,
`xl` 80rem, `2xl` 96rem.

### Z-Index Scale

| Token          | Value | Use                       |
| -------------- | ----- | ------------------------- |
| `--z-dropdown` | 1000  | Select / dropdown menus   |
| `--z-sticky`   | 1100  | Sticky top nav            |
| `--z-overlay`  | 1200  | Dialog / Drawer backdrops |
| `--z-modal`    | 1300  | Dialog / Drawer content   |
| `--z-popover`  | 1400  | Popover / Select content  |
| `--z-tooltip`  | 1500  | Tooltip content           |
| `--z-toast`    | 1600  | Toast viewport            |

Consumed as `z-(--z-modal)` (Tailwind arbitrary-value syntax).

## Layout Primitives

`Page` → full-height app shell · `Container` → max-width + horizontal
padding · `Section` → vertical rhythm · `Stack` → flex row/column with a
gap scale · `Grid` → responsive column grid · `Content` → scrollable main
area · `Sidebar` (+ Header/Content/Footer) → fixed side panel · `TopNav`
(+ Start/End) → sticky top bar.

`DashboardLayout` and `AuthLayout` (in `src/layouts/`) compose these
primitives into ready-made page shells. Neither renders any navigation
items or business content of its own — both accept the real content as
props/children from the feature that uses them.

## Component Usage

A few representative examples; every component follows the same pattern —
plain props, `className` passthrough via `cn()`, and Radix primitives under
the hood for anything requiring focus management or ARIA semantics.

```tsx
<Button variant="outline" size="sm">Cancel</Button>

<Field>
  <FieldLabel htmlFor="email">
    Email <RequiredIndicator />
  </FieldLabel>
  <Input id="email" type="email" placeholder="you@example.com" />
  <FieldHint>We'll never share your email.</FieldHint>
</Field>

<Dialog>
  <DialogTrigger asChild>
    <Button>Open</Button>
  </DialogTrigger>
  <DialogContent>
    <DialogHeader>
      <DialogTitle>Confirm</DialogTitle>
      <DialogDescription>Are you sure?</DialogDescription>
    </DialogHeader>
  </DialogContent>
</Dialog>

toast({ title: "Saved", description: "Your changes were saved." })
```

## Accessibility Rules

- Any component involving focus trapping, portals, or complex keyboard
  interaction (Dialog, Drawer, Popover, Tooltip, Select, Tabs, Accordion,
  Toast, Checkbox, Switch, Radio) is built on a Radix UI primitive — never
  hand-rolled.
- Icon-only controls (`IconButton`) require a `label` prop, applied as
  `aria-label`.
- Status-only visuals (`Spinner`) carry `role="status"` and an `sr-only`
  text label.
- Form errors (`FieldError`) use `role="alert"` so assistive tech announces
  them as they appear.
- Focus rings use the shared `ring` token (`focus-visible:ring-ring/50`)
  and are never removed without a replacement indicator.
- Color is never the only signal — status components always pair color
  with an icon and a text label.

## Icons

Lucide React is configured once, in `src/components/icons/index.ts`. No
other file imports from `lucide-react` directly — this keeps the icon set
swappable in a single place. Add new icons by re-exporting them there.

## Folder Structure

```
src/
├── components/
│   ├── ui/          # Design-system primitives (button, input, dialog, ...)
│   ├── layout/       # Layout primitives (container, stack, grid, ...)
│   ├── feedback/      # Status-state components
│   └── icons/          # Central Lucide re-export
├── layouts/           # Full-page layout shells (Main, Dashboard, Auth)
├── styles/            # globals.css — all design tokens
├── utils/              # format.ts — formatCurrency/Date/Number, truncate
├── hooks/               # use-toast.ts
└── providers/            # QueryProvider, UIProvider (Tooltip + Toaster)
```

## Restrictions Honored

This design system intentionally contains **no** authentication, product,
inventory, cart, checkout, admin-page, API, or backend code — every
component here is presentational/structural and takes its data through
props.
